<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $collectionName = $_POST['collection'];
    $remark = $_POST['remark'];

    // Create a database connection
    $servername = "your_servername";
    $username = "your_username";
    $password = "your_password";
    $dbname = "your_database_name";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement for inserting form data
    $sql = "INSERT INTO your_table_name (collection_of_title, general_discussion)
            VALUES ('$collectionName', '$remark')";

    // Execute SQL statement
    if ($conn->query($sql) === TRUE) {
        echo "Form data has been saved.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close database connection
    $conn->close();
}

// Retrieve data from the database
$servername = "your_servername";
$username = "your_username";
$password = "your_password";
$dbname = "your_database_name";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM your_table_name";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        /* CSS styles for the HTML form */

        /* Add your CSS styles here */

    </style>
</head>
<body>
    <h2>Purpose of visit.</h2>
    <p>Please state the purpose of your visit.</p>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <input type="checkbox" id="collection" name="collection" value="Collection">
        <label for="collection"> (A) Collection of Title</label><br>
        <input type="text" id="collection" name="collectionName" value="Name of Developer:"><br>
        <input type="checkbox" id="discussion" name="discussion" value="Discussion">
        <label for="discussion"> (B) General Discussion</label><br>
        <input type="text" id="discussion" name="remark" value="Remark:"><br>
        <input type="submit" class="submit" value="Submit">
    </form>

    <h2>Previous Form Data:</h2>
    <?php
    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "Collection of Title: " . $row["collection_of_title"] . "<br>";
            echo "General Discussion: " . $row["general_discussion"] . "<br>";
            echo "<hr>";
        }
    } else {
        echo "No results found.";
    }
    ?>
</body>
</html>
