<?php

//Xampp

	$host = "localhost";
	$user = "root"; // your user name
	$pwd = ""; // your password (date of birth ddmmyy unless changed)
	$sql_db = "etcs_database"; // your database


//000Web

?>
	
	
	