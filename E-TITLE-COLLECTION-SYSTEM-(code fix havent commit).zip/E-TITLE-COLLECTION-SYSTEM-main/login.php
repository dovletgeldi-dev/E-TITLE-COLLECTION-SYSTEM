<?php
// Database connection details
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "etcs_database";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function login($username, $password) {
    global $conn;

    // Prepare the SQL statement
    $sql = "SELECT * FROM admin WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Username exists, fetch the row
        $row = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $row['admin'])) {
            // Password is correct, login successful
            return true;
        }
    }

    // Invalid username or password
    return false;
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the submitted username and password
    $username = $_POST['admin'];
    $password = $_POST['admin'];

    // Perform login
    if (login($username, $password)) {
        echo "Login successful";
    } else {
        echo "Invalid username or password";
    }
}

// Close the connection
$conn->close();
?>
