CREATE TABLE purpose (
  collection_of_title VARCHAR(255),
  general_discussion VARCHAR(255) DEFAULT NULL
);
